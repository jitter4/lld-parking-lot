package lld.parkinglot.handler;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ParkingLotCommandHandlerTest {

    @Test
    void leaveSlot() {
    }

    @Test
    void getRegistrationNumbersByColor() {
    }

    @Test
    void getSlotNumbersByColor() {
    }

    @Test
    void getSlotNumberForRegistrationNumber() {
    }
}